import { Lightbulb, ShieldCheck, Zap } from "lucide-react";

export default function About() {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-accent-600 font-semibold tracking-wide uppercase">Technology</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            How It Works
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our platform combines AI and blockchain technologies to provide secure certificate verification
          </p>
        </div>

        <div className="mt-10">
          <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
            {/* Feature 1 */}
            <div className="relative">
              <dt>
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-accent-500 text-white">
                  <Lightbulb className="h-6 w-6" />
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900">AI Text Extraction</p>
              </dt>
              <dd className="mt-2 ml-16 text-base text-gray-500">
                Our system uses Tesseract OCR technology to extract text data from uploaded certificates (PDFs or images). This data is then processed to identify key certificate information.
              </dd>
            </div>

            {/* Feature 2 */}
            <div className="relative">
              <dt>
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-accent-500 text-white">
                  <ShieldCheck className="h-6 w-6" />
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900">Secure Hashing</p>
              </dt>
              <dd className="mt-2 ml-16 text-base text-gray-500">
                The extracted certificate data is processed through a SHA-256 hashing algorithm, creating a unique digital fingerprint that can be used to verify the certificate's authenticity.
              </dd>
            </div>

            {/* Feature 3 */}
            <div className="relative">
              <dt>
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-accent-500 text-white">
                  <Zap className="h-6 w-6" />
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900">Blockchain Storage</p>
              </dt>
              <dd className="mt-2 ml-16 text-base text-gray-500">
                The certificate hash is stored on the Polygon Mumbai Testnet blockchain, creating a tamper-proof record that can be independently verified by anyone with the certificate.
              </dd>
            </div>
          </dl>
        </div>

        <div className="mt-16 bg-gray-50 overflow-hidden rounded-lg shadow-lg">
          <div className="px-6 py-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Technical Process Flow</h3>
            
            <ol className="relative border-l border-gray-200">
              <li className="mb-10 ml-6">
                <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-500 rounded-full -left-4 ring-4 ring-white text-white">1</span>
                <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">Certificate Upload</h3>
                <p className="mb-4 text-base font-normal text-gray-500">
                  Institutions upload certificate documents (PDF/Image) through our secure interface.
                </p>
              </li>
              <li className="mb-10 ml-6">
                <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-500 rounded-full -left-4 ring-4 ring-white text-white">2</span>
                <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">OCR Processing</h3>
                <p className="mb-4 text-base font-normal text-gray-500">
                  Our AI system uses Tesseract OCR to extract text from the certificate file.
                </p>
              </li>
              <li className="mb-10 ml-6">
                <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-500 rounded-full -left-4 ring-4 ring-white text-white">3</span>
                <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">Hash Generation</h3>
                <p className="mb-4 text-base font-normal text-gray-500">
                  A unique SHA-256 hash is generated from the extracted certificate data.
                </p>
              </li>
              <li className="mb-10 ml-6">
                <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-500 rounded-full -left-4 ring-4 ring-white text-white">4</span>
                <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">Blockchain Storage</h3>
                <p className="mb-4 text-base font-normal text-gray-500">
                  The hash is stored on the Polygon Mumbai Testnet using our smart contract.
                </p>
              </li>
              <li className="ml-6">
                <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-500 rounded-full -left-4 ring-4 ring-white text-white">5</span>
                <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">Verification</h3>
                <p className="mb-4 text-base font-normal text-gray-500">
                  Recruiters can verify certificates by uploading them or entering the hash directly.
                </p>
              </li>
            </ol>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Powered by Polygon Mumbai Testnet</h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our platform utilizes the Polygon Mumbai Testnet for fast, low-cost blockchain transactions while maintaining the security and immutability benefits of blockchain technology.
          </p>
          
          <div className="mt-10 flex flex-col md:flex-row justify-center items-center gap-6">
            <div className="bg-white shadow-md rounded-lg p-6 max-w-sm">
              <h4 className="text-xl font-semibold mb-3">For Educational Institutions</h4>
              <p className="text-gray-600">
                Streamline your certificate issuance process and provide tamper-proof verification for all graduates.
              </p>
            </div>
            
            <div className="bg-white shadow-md rounded-lg p-6 max-w-sm">
              <h4 className="text-xl font-semibold mb-3">For Recruiters</h4>
              <p className="text-gray-600">
                Quickly verify candidate credentials without lengthy background checks or contacting institutions.
              </p>
            </div>
            
            <div className="bg-white shadow-md rounded-lg p-6 max-w-sm">
              <h4 className="text-xl font-semibold mb-3">For Certificate Holders</h4>
              <p className="text-gray-600">
                Share your verified credentials with confidence, knowing they can be easily authenticated.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
