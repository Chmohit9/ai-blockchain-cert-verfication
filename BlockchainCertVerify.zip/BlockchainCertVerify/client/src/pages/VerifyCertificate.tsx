import { useState, useRef, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, AlertTriangle, CircleCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatTransactionLink } from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VerificationResponse {
  verified: boolean;
  message?: string;
  certificate?: {
    id: number;
    hash: string;
    holder_name: string;
    certificate_type: string;
    issue_date: string;
    transaction_hash: string;
    issuer_id: number;
  };
}

export default function VerifyCertificate() {
  const [fileName, setFileName] = useState("");
  const [verificationResult, setVerificationResult] = useState<VerificationResponse | null>(null);
  const [showResult, setShowResult] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const fileFormRef = useRef<HTMLFormElement>(null);
  const hashFormRef = useRef<HTMLFormElement>(null);
  
  const { toast } = useToast();

  // Mutation for verifying certificate by file
  const verifyFileMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest('POST', '/api/certificates/verify/file', formData);
      return await response.json() as VerificationResponse;
    },
    onSuccess: (data) => {
      setVerificationResult(data);
      setShowResult(true);
      
      if (data.verified) {
        toast({
          title: "Certificate Verified",
          description: "The certificate has been successfully verified on the blockchain.",
        });
      } else {
        toast({
          title: "Verification Failed",
          description: data.message || "The certificate could not be verified.",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message || "There was an error verifying the certificate.",
        variant: "destructive",
      });
      setShowResult(false);
    }
  });

  // Mutation for verifying certificate by hash
  const verifyHashMutation = useMutation({
    mutationFn: async (hash: string) => {
      const response = await apiRequest('POST', '/api/certificates/verify/hash', { hash });
      return await response.json() as VerificationResponse;
    },
    onSuccess: (data) => {
      setVerificationResult(data);
      setShowResult(true);
      
      if (data.verified) {
        toast({
          title: "Certificate Verified",
          description: "The certificate has been successfully verified on the blockchain.",
        });
      } else {
        toast({
          title: "Verification Failed",
          description: data.message || "The certificate could not be verified.",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message || "There was an error verifying the certificate.",
        variant: "destructive",
      });
      setShowResult(false);
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.dataTransfer.files?.length) {
      const file = e.dataTransfer.files[0];
      setFileName(file.name);
      
      // Update file input
      if (fileInputRef.current) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInputRef.current.files = dataTransfer.files;
      }
    }
  };

  const handleFileSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!fileInputRef.current?.files?.length) {
      toast({
        title: "No File Selected",
        description: "Please select a file to verify.",
        variant: "destructive",
      });
      return;
    }
    
    setShowResult(false);
    const formData = new FormData(fileFormRef.current!);
    verifyFileMutation.mutate(formData);
  };

  const handleHashSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    const formData = new FormData(hashFormRef.current!);
    const hash = formData.get('certificate-hash') as string;
    
    if (!hash) {
      toast({
        title: "No Hash Provided",
        description: "Please enter a certificate hash to verify.",
        variant: "destructive",
      });
      return;
    }
    
    setShowResult(false);
    verifyHashMutation.mutate(hash);
  };

  const resetVerification = () => {
    setShowResult(false);
    setVerificationResult(null);
    setFileName("");
    fileFormRef.current?.reset();
    hashFormRef.current?.reset();
  };

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-secondary-600 font-semibold tracking-wide uppercase">For Recruiters</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Verify Certificate Authenticity
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Upload or enter certificate details to verify its authenticity against blockchain records
          </p>
        </div>

        <div className="mt-10">
          <Card className="bg-white shadow">
            <CardContent className="px-4 py-5 sm:p-6">
              <Tabs defaultValue="upload">
                <TabsList className="w-full border-b border-gray-200">
                  <TabsTrigger 
                    value="upload" 
                    className="border-secondary-500 text-secondary-600 hover:text-secondary-700 hover:border-secondary-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                  >
                    Verify by Upload
                  </TabsTrigger>
                  <TabsTrigger 
                    value="hash" 
                    className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                  >
                    Verify by Certificate Hash
                  </TabsTrigger>
                </TabsList>

                {/* Upload Verification Form */}
                <TabsContent value="upload" className="mt-6">
                  <div className="bg-white shadow sm:rounded-lg">
                    <div className="px-4 py-5 sm:px-6">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">
                        Upload Certificate for Verification
                      </h3>
                      <p className="mt-1 max-w-2xl text-sm text-gray-500">
                        Upload the certificate file to verify its authenticity
                      </p>
                    </div>
                    <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                      <form ref={fileFormRef} onSubmit={handleFileSubmit}>
                        <div 
                          className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md"
                          onDragOver={handleDragOver}
                          onDrop={handleDrop}
                        >
                          <div className="space-y-1 text-center">
                            <Upload className="mx-auto h-12 w-12 text-gray-400" />
                            <div className="flex text-sm text-gray-600">
                              <label htmlFor="verify-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-secondary-600 hover:text-secondary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-secondary-500">
                                <span>Upload a file</span>
                                <input 
                                  id="verify-file-upload" 
                                  name="certificate" 
                                  type="file" 
                                  className="sr-only" 
                                  accept=".pdf,.jpg,.jpeg,.png"
                                  ref={fileInputRef}
                                  onChange={handleFileChange}
                                  disabled={verifyFileMutation.isPending}
                                  required
                                />
                              </label>
                              <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs text-gray-500">
                              PDF, PNG, JPG up to 10MB
                            </p>
                            {fileName && (
                              <p className="text-sm text-primary-600 mt-2">{fileName}</p>
                            )}
                          </div>
                        </div>
                        <div className="mt-5 flex justify-end">
                          <Button
                            type="submit"
                            className="bg-secondary-600 hover:bg-secondary-700"
                            disabled={verifyFileMutation.isPending}
                          >
                            {verifyFileMutation.isPending ? "Verifying..." : "Verify Certificate"}
                          </Button>
                        </div>
                      </form>
                    </div>
                  </div>
                </TabsContent>

                {/* Hash Verification Form */}
                <TabsContent value="hash" className="mt-6">
                  <div className="bg-white shadow sm:rounded-lg">
                    <div className="px-4 py-5 sm:px-6">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">
                        Verify by Certificate Hash
                      </h3>
                      <p className="mt-1 max-w-2xl text-sm text-gray-500">
                        Enter the certificate hash to verify its authenticity
                      </p>
                    </div>
                    <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                      <form ref={hashFormRef} onSubmit={handleHashSubmit}>
                        <div>
                          <Label htmlFor="certificate-hash">Certificate Hash</Label>
                          <div className="mt-1">
                            <Input
                              type="text"
                              name="certificate-hash"
                              id="certificate-hash"
                              className="font-mono"
                              placeholder="0x..."
                              required
                              disabled={verifyHashMutation.isPending}
                            />
                          </div>
                          <p className="mt-2 text-sm text-gray-500">
                            Enter the complete hash provided by the certificate issuer or displayed on the certificate.
                          </p>
                        </div>
                        <div className="mt-5 flex justify-end">
                          <Button
                            type="submit"
                            className="bg-secondary-600 hover:bg-secondary-700"
                            disabled={verifyHashMutation.isPending}
                          >
                            {verifyHashMutation.isPending ? "Verifying..." : "Verify Hash"}
                          </Button>
                        </div>
                      </form>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              {/* Verification Results */}
              {showResult && verificationResult && (
                <>
                  {verificationResult.verified ? (
                    <div className="mt-8">
                      <div className="rounded-md bg-green-50 p-4">
                        <div className="flex">
                          <div className="flex-shrink-0">
                            <CircleCheck className="h-5 w-5 text-green-400" />
                          </div>
                          <div className="ml-3">
                            <h3 className="text-sm font-medium text-green-800">
                              Certificate Verified
                            </h3>
                            <div className="mt-2 text-sm text-green-700">
                              <p>
                                This certificate has been verified as authentic. It was issued by an authorized institution and is stored securely on the blockchain.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Certificate Details */}
                      <div className="mt-6 bg-white shadow sm:rounded-lg">
                        <div className="px-4 py-5 sm:px-6">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Certificate Information
                          </h3>
                          <p className="mt-1 max-w-2xl text-sm text-gray-500">
                            Details extracted from the verified certificate
                          </p>
                        </div>
                        <div className="border-t border-gray-200">
                          <dl>
                            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Certificate Holder
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                {verificationResult.certificate?.holder_name}
                              </dd>
                            </div>
                            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Issuing Institution
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                {`Institution ID: ${verificationResult.certificate?.issuer_id}`}
                              </dd>
                            </div>
                            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Certificate Type
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                {verificationResult.certificate?.certificate_type}
                              </dd>
                            </div>
                            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Issue Date
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                {verificationResult.certificate?.issue_date ? formatDate(verificationResult.certificate.issue_date) : ''}
                              </dd>
                            </div>
                            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Certificate Hash
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                <span className="font-mono text-xs bg-gray-100 p-2 rounded block overflow-x-auto whitespace-nowrap hash-display">
                                  {verificationResult.certificate?.hash}
                                </span>
                              </dd>
                            </div>
                            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                              <dt className="text-sm font-medium text-gray-500">
                                Blockchain Record
                              </dt>
                              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                <a 
                                  href={verificationResult.certificate?.transaction_hash ? formatTransactionLink(verificationResult.certificate.transaction_hash) : '#'} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-secondary-600 hover:text-secondary-500 break-all font-mono text-xs"
                                >
                                  {verificationResult.certificate?.transaction_hash}
                                </a>
                              </dd>
                            </div>
                          </dl>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-8">
                      <div className="rounded-md bg-red-50 p-4">
                        <div className="flex">
                          <div className="flex-shrink-0">
                            <AlertTriangle className="h-5 w-5 text-red-400" />
                          </div>
                          <div className="ml-3">
                            <h3 className="text-sm font-medium text-red-800">
                              Verification Failed
                            </h3>
                            <div className="mt-2 text-sm text-red-700">
                              <p>
                                This certificate could not be verified. The certificate hash was not found in our blockchain records.
                              </p>
                              <ul className="list-disc pl-5 mt-1">
                                <li>The certificate may have been altered</li>
                                <li>The certificate may not have been issued by a registered institution</li>
                                <li>There may be an error in the certificate data</li>
                              </ul>
                            </div>
                            <div className="mt-4">
                              <div className="-mx-2 -my-1.5 flex">
                                <Button
                                  className="bg-red-50 px-2 py-1.5 rounded-md text-sm font-medium text-red-800 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-red-50 focus:ring-red-600"
                                  onClick={resetVerification}
                                >
                                  Try Again
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
