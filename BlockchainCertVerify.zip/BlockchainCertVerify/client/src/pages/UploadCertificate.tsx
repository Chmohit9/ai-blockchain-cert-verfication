import { useState, useRef, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clipboard, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatTransactionLink } from "@/lib/utils";
import { useWallet } from "@/hooks/use-wallet";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface UploadResponse {
  message: string;
  certificate: {
    id: number;
    hash: string;
    holder_name: string;
    certificate_type: string;
    issue_date: string;
    transaction_hash: string;
  };
}

export default function UploadCertificate() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isLoading, setIsLoading] = useState(false);
  const [fileName, setFileName] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [certificateResult, setCertificateResult] = useState<UploadResponse | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const { toast } = useToast();
  const { isConnected, isCorrectChain } = useWallet();

  // Mutation for uploading certificate
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest('POST', '/api/certificates/upload', formData);
      return await response.json() as UploadResponse;
    },
    onSuccess: (data) => {
      setCertificateResult(data);
      setShowResult(true);
      setStep(3);
      toast({
        title: "Certificate Processed",
        description: "The certificate has been successfully processed and stored on the blockchain.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Processing Failed",
        description: error.message || "There was an error processing the certificate.",
        variant: "destructive",
      });
      setStep(1);
    },
    onSettled: () => {
      setIsLoading(false);
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.dataTransfer.files?.length) {
      const file = e.dataTransfer.files[0];
      setFileName(file.name);
      
      // Update file input
      if (fileInputRef.current) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInputRef.current.files = dataTransfer.files;
      }
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    // Check if wallet is connected - for development, proceed anyway
    if (!isConnected && process.env.NODE_ENV !== 'development') {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to upload certificates.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if on correct chain - for development, proceed anyway
    if (!isCorrectChain && process.env.NODE_ENV !== 'development') {
      toast({
        title: "Wrong Network",
        description: "Please switch to Polygon Mumbai Testnet.",
        variant: "destructive",
      });
      return;
    }
    
    if (!fileInputRef.current?.files?.length) {
      toast({
        title: "No File Selected",
        description: "Please select a file to upload.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    setStep(2);
    
    const formData = new FormData(formRef.current!);
    uploadMutation.mutate(formData);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to Clipboard",
      description: "The certificate hash has been copied to your clipboard.",
    });
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-primary-600 font-semibold tracking-wide uppercase">For Institutions</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Upload & Secure Certificates
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Upload certificate documents to be processed by AI and secured on the blockchain
          </p>
        </div>

        <div className="mt-10">
          <Card className="bg-gray-50 shadow">
            <CardContent className="px-4 py-5 sm:p-6">
              {/* Progress Steps */}
              <div className="py-4">
                <div className="flex items-center justify-center">
                  <ol className="flex items-center w-full max-w-3xl">
                    {/* Step 1 */}
                    <li className={`flex items-center space-x-2.5 after:content-[''] after:w-12 after:h-1 after:border-b after:border-4 after:inline-block sm:after:w-32 ${
                      step >= 1 
                        ? "text-primary-600 after:border-primary-100" 
                        : "text-gray-500 after:border-gray-200"
                    }`}>
                      <span className={`flex items-center justify-center w-8 h-8 border rounded-full shrink-0 ${
                        step >= 1 
                          ? "border-primary-600 bg-primary-500 text-white" 
                          : "border-gray-500"
                      }`}>
                        1
                      </span>
                      <span>
                        <h3 className="font-medium leading-tight">Upload</h3>
                        <p className="text-sm">Select certificate file</p>
                      </span>
                    </li>
                    
                    {/* Step 2 */}
                    <li className={`flex items-center space-x-2.5 after:content-[''] after:w-12 after:h-1 after:border-b after:border-4 after:inline-block sm:after:w-32 ${
                      step >= 2 
                        ? "text-primary-600 after:border-primary-100" 
                        : "text-gray-500 after:border-gray-200"
                    }`}>
                      <span className={`flex items-center justify-center w-8 h-8 border rounded-full shrink-0 ${
                        step >= 2 
                          ? "border-primary-600 bg-primary-500 text-white" 
                          : "border-gray-500"
                      }`}>
                        2
                      </span>
                      <span>
                        <h3 className="font-medium leading-tight">AI Processing</h3>
                        <p className="text-sm">Extract certificate data</p>
                      </span>
                    </li>
                    
                    {/* Step 3 */}
                    <li className={`flex items-center space-x-2.5 ${
                      step >= 3 
                        ? "text-primary-600" 
                        : "text-gray-500"
                    }`}>
                      <span className={`flex items-center justify-center w-8 h-8 border rounded-full shrink-0 ${
                        step >= 3 
                          ? "border-primary-600 bg-primary-500 text-white" 
                          : "border-gray-500"
                      }`}>
                        3
                      </span>
                      <span>
                        <h3 className="font-medium leading-tight">Blockchain</h3>
                        <p className="text-sm">Store hash securely</p>
                      </span>
                    </li>
                  </ol>
                </div>
              </div>

              {/* Form */}
              <form ref={formRef} onSubmit={handleSubmit} className="space-y-8 divide-y divide-gray-200">
                <div className="space-y-8 divide-y divide-gray-200">
                  <div>
                    <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                      <div className="sm:col-span-3">
                        <Label htmlFor="institution-name">Institution Name</Label>
                        <div className="mt-1">
                          <Input 
                            type="text" 
                            id="institution-name" 
                            name="institution_name" 
                            required
                            disabled={isLoading || showResult}
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-3">
                        <Label htmlFor="institution-id">Institution ID</Label>
                        <div className="mt-1">
                          <Input 
                            type="text" 
                            id="institution-id" 
                            name="institution_id" 
                            required
                            disabled={isLoading || showResult}
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-6">
                        <Label htmlFor="certificate-type">Certificate Type</Label>
                        <div className="mt-1">
                          <Select name="certificate_type" disabled={isLoading || showResult} required defaultValue="Degree Certificate">
                            <SelectTrigger>
                              <SelectValue placeholder="Select certificate type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Degree Certificate">Degree Certificate</SelectItem>
                              <SelectItem value="Diploma">Diploma</SelectItem>
                              <SelectItem value="Training Certificate">Training Certificate</SelectItem>
                              <SelectItem value="Professional Certification">Professional Certification</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="sm:col-span-6">
                        <Label>Certificate File</Label>
                        <div 
                          className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md"
                          onDragOver={handleDragOver}
                          onDrop={handleDrop}
                        >
                          <div className="space-y-1 text-center">
                            <Upload className="mx-auto h-12 w-12 text-gray-400" />
                            <div className="flex text-sm text-gray-600">
                              <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500">
                                <span>Upload a file</span>
                                <input 
                                  id="file-upload" 
                                  name="certificate" 
                                  type="file" 
                                  className="sr-only" 
                                  accept=".pdf,.jpg,.jpeg,.png"
                                  ref={fileInputRef}
                                  onChange={handleFileChange}
                                  disabled={isLoading || showResult}
                                  required
                                />
                              </label>
                              <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs text-gray-500">
                              PDF, PNG, JPG up to 10MB
                            </p>
                            {fileName && (
                              <p className="text-sm text-primary-600 mt-2">{fileName}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-5">
                  <div className="flex justify-end">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        formRef.current?.reset();
                        setFileName("");
                        setStep(1);
                        setShowResult(false);
                      }}
                      disabled={isLoading}
                    >
                      Reset
                    </Button>
                    <Button
                      type="submit"
                      className="ml-3 bg-primary-600 hover:bg-primary-700"
                      disabled={isLoading || showResult}
                    >
                      {isLoading ? "Processing..." : "Process Certificate"}
                    </Button>
                  </div>
                </div>
              </form>

              {/* Certificate Result Preview */}
              {showResult && certificateResult && (
                <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
                  <div className="px-4 py-5 sm:px-6">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">
                      Certificate Processing Results
                    </h3>
                    <p className="mt-1 max-w-2xl text-sm text-gray-500">
                      Certificate successfully processed and stored on blockchain
                    </p>
                  </div>
                  <div className="border-t border-gray-200">
                    <dl>
                      <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Certificate Holder
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          {certificateResult.certificate.holder_name}
                        </dd>
                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Certificate Type
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          {certificateResult.certificate.certificate_type}
                        </dd>
                      </div>
                      <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Issue Date
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          {formatDate(certificateResult.certificate.issue_date)}
                        </dd>
                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Certificate Hash
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          <div className="flex items-center">
                            <span className="font-mono text-xs bg-gray-100 p-2 rounded hash-display overflow-x-auto whitespace-nowrap">
                              {certificateResult.certificate.hash}
                            </span>
                            <button 
                              type="button" 
                              className="ml-2 p-1 rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                              onClick={() => copyToClipboard(certificateResult.certificate.hash)}
                            >
                              <span className="sr-only">Copy hash</span>
                              <Clipboard className="h-5 w-5" />
                            </button>
                          </div>
                        </dd>
                      </div>
                      <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Blockchain Transaction
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          <a 
                            href={formatTransactionLink(certificateResult.certificate.transaction_hash)} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary-600 hover:text-primary-500 font-mono text-xs"
                          >
                            {certificateResult.certificate.transaction_hash}
                          </a>
                        </dd>
                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">
                          Status
                        </dt>
                        <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Verified & Secured
                          </span>
                        </dd>
                      </div>
                    </dl>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
