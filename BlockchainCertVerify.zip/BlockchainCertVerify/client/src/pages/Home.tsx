import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, CheckCircle, Database } from "lucide-react";

export default function Home() {
  return (
    <div className="relative bg-gray-50 pt-16 pb-20 px-4 sm:px-6 lg:pt-24 lg:pb-28 lg:px-8">
      <div className="absolute inset-0">
        <div className="bg-white h-1/3 sm:h-2/3"></div>
      </div>
      <div className="relative max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl tracking-tight font-extrabold text-gray-900 sm:text-4xl">
            AI + Blockchain Certificate Verification
          </h1>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Securely upload, verify, and manage academic certificates using AI and blockchain technology
          </p>
        </div>

        {/* Features Grid */}
        <div className="mt-12 max-w-lg mx-auto grid gap-5 lg:grid-cols-3 lg:max-w-none">
          {/* Feature Card 1 */}
          <div className="flex flex-col rounded-lg shadow-lg overflow-hidden">
            <div className="flex-shrink-0 bg-primary-500 py-5 flex justify-center">
              <FileText className="h-16 w-16 text-white" />
            </div>
            <div className="flex-1 bg-white p-6 flex flex-col justify-between">
              <div className="flex-1">
                <div className="block">
                  <h3 className="mt-2 text-xl font-semibold text-gray-900">
                    Certificate Upload
                  </h3>
                  <p className="mt-3 text-base text-gray-500">
                    Institutions can securely upload certificates for verification. Our AI extracts and processes the data.
                  </p>
                </div>
              </div>
              <div className="mt-6">
                <Link href="/upload">
                  <Button className="bg-primary-600 hover:bg-primary-700 w-full">
                    Upload Certificate
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Feature Card 2 */}
          <div className="flex flex-col rounded-lg shadow-lg overflow-hidden">
            <div className="flex-shrink-0 bg-secondary-500 py-5 flex justify-center">
              <CheckCircle className="h-16 w-16 text-white" />
            </div>
            <div className="flex-1 bg-white p-6 flex flex-col justify-between">
              <div className="flex-1">
                <div className="block">
                  <h3 className="mt-2 text-xl font-semibold text-gray-900">
                    Certificate Verification
                  </h3>
                  <p className="mt-3 text-base text-gray-500">
                    Recruiters can verify the authenticity of certificates by checking the blockchain-stored hash.
                  </p>
                </div>
              </div>
              <div className="mt-6">
                <Link href="/verify">
                  <Button className="bg-secondary-500 hover:bg-secondary-600 w-full">
                    Verify Certificate
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Feature Card 3 */}
          <div className="flex flex-col rounded-lg shadow-lg overflow-hidden">
            <div className="flex-shrink-0 bg-accent-500 py-5 flex justify-center">
              <Database className="h-16 w-16 text-white" />
            </div>
            <div className="flex-1 bg-white p-6 flex flex-col justify-between">
              <div className="flex-1">
                <div className="block">
                  <h3 className="mt-2 text-xl font-semibold text-gray-900">
                    Blockchain Security
                  </h3>
                  <p className="mt-3 text-base text-gray-500">
                    Every certificate is secured with blockchain technology, ensuring data integrity and immutable records.
                  </p>
                </div>
              </div>
              <div className="mt-6">
                <Link href="/about">
                  <Button className="bg-accent-500 hover:bg-accent-600 w-full">
                    Learn How It Works
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
