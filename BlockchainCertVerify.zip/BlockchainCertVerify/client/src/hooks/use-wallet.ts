import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  isMetaMaskInstalled, 
  requestAccounts, 
  getChainId, 
  switchToMumbai, 
  MUMBAI_CHAIN_ID 
} from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';

// Define the wallet context type
interface WalletContextType {
  isConnected: boolean;
  address: string | null;
  isCorrectChain: boolean;
  balance: string | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  switchNetwork: () => Promise<void>;
}

// Create the wallet context with default values
const WalletContext = createContext<WalletContextType>({
  isConnected: false,
  address: null,
  isCorrectChain: false,
  balance: null,
  connect: async () => {},
  disconnect: () => {},
  switchNetwork: async () => {},
});

// Provider component for the wallet context
export function WalletProvider({ children }: { children: ReactNode }) {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [address, setAddress] = useState<string | null>(null);
  const [isCorrectChain, setIsCorrectChain] = useState<boolean>(false);
  const [balance, setBalance] = useState<string | null>(null);
  const { toast } = useToast();

  // Check if already connected on mount
  useEffect(() => {
    const checkConnection = async () => {
      if (isMetaMaskInstalled()) {
        try {
          // Get accounts
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          
          if (accounts.length > 0) {
            setAddress(accounts[0]);
            setIsConnected(true);
            
            // Check chain
            const chainId = await getChainId();
            setIsCorrectChain(chainId === MUMBAI_CHAIN_ID);
            
            // Get balance
            const balance = await window.ethereum.request({
              method: 'eth_getBalance',
              params: [accounts[0], 'latest']
            });
            
            setBalance(balance);
          }
        } catch (error) {
          console.error('Error checking connection:', error);
        }
      }
    };
    
    checkConnection();
  }, []);

  // Set up event listeners
  useEffect(() => {
    if (isMetaMaskInstalled()) {
      // Handle account changes
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          // Disconnected
          setIsConnected(false);
          setAddress(null);
          setBalance(null);
        } else {
          // Account changed
          setAddress(accounts[0]);
          setIsConnected(true);
        }
      };
      
      // Handle chain changes
      const handleChainChanged = async () => {
        const chainId = await getChainId();
        setIsCorrectChain(chainId === MUMBAI_CHAIN_ID);
      };
      
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
      
      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, []);

  // Connect wallet
  const connect = async () => {
    if (!isMetaMaskInstalled()) {
      toast({
        title: "MetaMask Not Found",
        description: "Please install MetaMask extension to continue.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Request accounts
      const accounts = await requestAccounts();
      
      if (accounts.length > 0) {
        setAddress(accounts[0]);
        setIsConnected(true);
        
        // Check chain
        const chainId = await getChainId();
        const correctChain = chainId === MUMBAI_CHAIN_ID;
        setIsCorrectChain(correctChain);
        
        // If not on correct chain, prompt to switch
        if (!correctChain) {
          toast({
            title: "Wrong Network",
            description: "Please switch to Polygon Mumbai Testnet.",
            variant: "destructive"
          });
        }
        
        // Get balance
        const balance = await window.ethereum.request({
          method: 'eth_getBalance',
          params: [accounts[0], 'latest']
        });
        
        setBalance(balance);
        
        toast({
          title: "Wallet Connected",
          description: "Your wallet has been connected successfully.",
          variant: "default"
        });
      }
    } catch (error: any) {
      console.error('Error connecting wallet:', error);
      toast({
        title: "Connection Failed",
        description: error.message || "Could not connect to wallet.",
        variant: "destructive"
      });
    }
  };

  // Disconnect wallet (frontend only)
  const disconnect = () => {
    setIsConnected(false);
    setAddress(null);
    setBalance(null);
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected.",
      variant: "default"
    });
  };

  // Switch to Mumbai network
  const switchNetwork = async () => {
    try {
      await switchToMumbai();
      setIsCorrectChain(true);
      
      toast({
        title: "Network Switched",
        description: "Successfully switched to Polygon Mumbai Testnet.",
        variant: "default"
      });
    } catch (error: any) {
      console.error('Error switching network:', error);
      toast({
        title: "Network Switch Failed",
        description: error.message || "Could not switch to Mumbai Testnet.",
        variant: "destructive"
      });
    }
  };

  return React.createElement(
    WalletContext.Provider,
    {
      value: {
        isConnected,
        address,
        isCorrectChain,
        balance,
        connect,
        disconnect,
        switchNetwork
      }
    },
    children
  );
}

// Custom hook to use the wallet context
export function useWallet() {
  return useContext(WalletContext);
}