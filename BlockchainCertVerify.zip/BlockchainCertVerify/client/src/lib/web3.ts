import { ethers } from 'ethers';

// Contract ABI (abbreviated, matching the Solidity contract)
const CONTRACT_ABI = [
  "function storeCertificateHash(string memory hash) public returns (bool)",
  "function verifyCertificateHash(string memory hash) public view returns (bool)"
];

// Supported chain information
export const MUMBAI_CHAIN_ID = 80001;
export const MUMBAI_CHAIN = {
  chainId: '0x13881',
  chainName: 'Polygon Mumbai Testnet',
  nativeCurrency: {
    name: 'MATIC',
    symbol: 'MATIC',
    decimals: 18
  },
  rpcUrls: ['https://rpc-mumbai.maticvigil.com'],
  blockExplorerUrls: ['https://mumbai.polygonscan.com']
};

// Check if MetaMask is installed
export function isMetaMaskInstalled(): boolean {
  return typeof window !== 'undefined' && typeof window.ethereum !== 'undefined';
}

// Request account access from MetaMask
export async function requestAccounts(): Promise<string[]> {
  if (!isMetaMaskInstalled()) {
    throw new Error('MetaMask is not installed');
  }
  
  try {
    return await window.ethereum.request({ method: 'eth_requestAccounts' });
  } catch (error) {
    console.error('Error requesting accounts:', error);
    throw error;
  }
}

// Get the current chain ID
export async function getChainId(): Promise<number> {
  if (!isMetaMaskInstalled()) {
    throw new Error('MetaMask is not installed');
  }
  
  try {
    const chainId = await window.ethereum.request({ method: 'eth_chainId' });
    return parseInt(chainId, 16);
  } catch (error) {
    console.error('Error getting chain ID:', error);
    throw error;
  }
}

// Switch to Mumbai testnet
export async function switchToMumbai(): Promise<void> {
  if (!isMetaMaskInstalled()) {
    throw new Error('MetaMask is not installed');
  }
  
  try {
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: MUMBAI_CHAIN.chainId }]
    });
  } catch (error: any) {
    // If the chain hasn't been added to MetaMask, add it
    if (error.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [MUMBAI_CHAIN]
        });
      } catch (addError) {
        console.error('Error adding Mumbai chain:', addError);
        throw addError;
      }
    } else {
      console.error('Error switching to Mumbai chain:', error);
      throw error;
    }
  }
}

// Create a contract instance
export function getContract(address: string, provider: ethers.Provider): ethers.Contract {
  return new ethers.Contract(address, CONTRACT_ABI, provider);
}

// Create a provider
export function getProvider(): ethers.BrowserProvider {
  if (!isMetaMaskInstalled()) {
    throw new Error('MetaMask is not installed');
  }
  
  return new ethers.BrowserProvider(window.ethereum);
}

// Interface for the window.ethereum object
declare global {
  interface Window {
    ethereum: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, listener: (...args: any[]) => void) => void;
      removeListener: (event: string, listener: (...args: any[]) => void) => void;
    };
  }
}
