import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a blockchain address to a shortened form
export function formatAddress(address: string | undefined): string {
  if (!address) return "";
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

// Format a timestamp to a readable date
export function formatDate(date: Date | string | number): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

// Format a transaction hash with a link to the block explorer
export function formatTransactionLink(hash: string): string {
  return `https://mumbai.polygonscan.com/tx/${hash}`;
}

// Check if a file is a valid certificate format (PDF, JPG, PNG)
export function isValidCertificateFile(file: File): boolean {
  const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
  return validTypes.includes(file.type);
}

// Get file size in a readable format
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' bytes';
  else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
  else return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}
