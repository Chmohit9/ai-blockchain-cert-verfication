import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { WalletProvider } from './hooks/use-wallet';

// Render the App component
createRoot(document.getElementById("root")!).render(
  <WalletProvider>
    <App />
  </WalletProvider>
);
