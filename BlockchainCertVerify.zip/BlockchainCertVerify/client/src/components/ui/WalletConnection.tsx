import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";
import { formatAddress } from "@/lib/utils";

export function WalletConnection() {
  const { isConnected, address, connect, disconnect } = useWallet();

  return (
    <div>
      {isConnected ? (
        <Button 
          variant="outline" 
          className="bg-green-600 text-white hover:bg-green-700"
          onClick={disconnect}
        >
          {formatAddress(address || "")}
        </Button>
      ) : (
        <Button 
          className="bg-primary-600 hover:bg-primary-700"
          onClick={connect}
        >
          Connect Wallet
        </Button>
      )}
    </div>
  );
}

export default WalletConnection;
