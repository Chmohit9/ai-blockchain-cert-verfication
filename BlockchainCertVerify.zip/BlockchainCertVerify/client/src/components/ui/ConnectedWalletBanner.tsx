import { useWallet } from "@/hooks/use-wallet";
import { formatAddress } from "@/lib/utils";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ConnectedWalletBanner() {
  const { address, isCorrectChain, switchNetwork } = useWallet();
  
  return (
    <div className="bg-accent-500">
      <div className="max-w-7xl mx-auto py-2 px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between flex-wrap">
          <div className="w-0 flex-1 flex items-center">
            <span className="flex p-2 rounded-lg bg-accent-600">
              <AlertCircle className="h-5 w-5 text-white" />
            </span>
            <p className="ml-3 font-medium text-white truncate">
              {isCorrectChain ? (
                <span>Connected to Polygon Mumbai Testnet ({formatAddress(address || "")})</span>
              ) : (
                <span>Please switch to Polygon Mumbai Testnet</span>
              )}
            </p>
          </div>
          {!isCorrectChain && (
            <div className="order-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0 sm:w-auto">
              <Button
                onClick={switchNetwork}
                className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-accent-600 bg-white hover:bg-accent-50"
              >
                Switch Network
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ConnectedWalletBanner;
