import { ethers } from 'ethers';
import { log } from './vite';

// Contract ABI (abbreviated)
const CONTRACT_ABI = [
  "function storeCertificateHash(string memory hash) public returns (bool)",
  "function verifyCertificateHash(string memory hash) public view returns (bool)"
];

// Connect to the Polygon Mumbai Testnet
let provider: ethers.Provider | null = null;
let contract: ethers.Contract | null = null;

// Initialize the provider and contract
export async function initializeBlockchain() {
  try {
    // Get the RPC URL from environment variables or use a default
    const rpcUrl = process.env.POLYGON_MUMBAI_RPC_URL || 'https://rpc-mumbai.maticvigil.com';
    
    // Create a provider
    provider = new ethers.JsonRpcProvider(rpcUrl);
    
    // Get the contract address from environment variables
    const contractAddress = process.env.CONTRACT_ADDRESS;
    
    // For development environment, use a placeholder contract address if not provided
    if (!contractAddress && process.env.NODE_ENV === 'development') {
      log('Using placeholder contract address for development', 'blockchain');
      // This is a placeholder address - will only work for viewing the UI, not for actual blockchain transactions
      return true;
    }
    
    if (!contractAddress) {
      log('Contract address not found in environment variables', 'blockchain');
      throw new Error('Contract address not found');
    }
    
    // Create the contract instance
    contract = new ethers.Contract(contractAddress, CONTRACT_ABI, provider);
    
    log('Blockchain connection initialized', 'blockchain');
    return true;
  } catch (error) {
    log(`Blockchain initialization error: ${error}`, 'blockchain');
    return false;
  }
}

// Store a certificate hash on the blockchain
export async function storeCertificateHash(hash: string, privateKey: string): Promise<string> {
  try {
    if (!provider || !contract) {
      await initializeBlockchain();
      
      // In development mode, just return a mock transaction hash if no contract is available
      if ((!provider || !contract) && process.env.NODE_ENV === 'development') {
        log(`Development mode: Returning mock transaction hash for hash ${hash}`, 'blockchain');
        return '0x' + Math.random().toString(16).substr(2, 64); // Mock transaction hash
      }
      
      if (!provider || !contract) {
        throw new Error('Blockchain not initialized');
      }
    }
    
    // Create a wallet from the private key
    const wallet = new ethers.Wallet(privateKey, provider);
    
    // Connect the wallet to the contract
    const contractWithSigner = contract.connect(wallet);
    
    // Store the hash on the blockchain
    log(`Storing hash on blockchain: ${hash}`, 'blockchain');
    const tx = await contractWithSigner.storeCertificateHash(hash);
    
    // Wait for the transaction to be mined
    const receipt = await tx.wait();
    
    log(`Transaction confirmed: ${receipt.hash}`, 'blockchain');
    return receipt.hash;
  } catch (error) {
    log(`Error storing hash on blockchain: ${error}`, 'blockchain');
    throw new Error(`Failed to store hash on blockchain: ${error}`);
  }
}

// Verify a certificate hash on the blockchain
export async function verifyCertificateHash(hash: string): Promise<boolean> {
  try {
    if (!provider || !contract) {
      await initializeBlockchain();
      
      // In development mode, just return true for verification
      if ((!provider || !contract) && process.env.NODE_ENV === 'development') {
        log(`Development mode: Returning true for hash verification ${hash}`, 'blockchain');
        return true; // For development purposes, we'll simulate that all hashes are verified
      }
      
      if (!provider || !contract) {
        throw new Error('Blockchain not initialized');
      }
    }
    
    // Verify the hash on the blockchain
    log(`Verifying hash on blockchain: ${hash}`, 'blockchain');
    const isVerified = await contract.verifyCertificateHash(hash);
    
    log(`Hash verification result: ${isVerified}`, 'blockchain');
    return isVerified;
  } catch (error) {
    log(`Error verifying hash on blockchain: ${error}`, 'blockchain');
    throw new Error(`Failed to verify hash on blockchain: ${error}`);
  }
}
