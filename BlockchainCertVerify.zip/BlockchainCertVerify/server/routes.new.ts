import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertCertificateSchema, insertVerificationSchema } from "@shared/schema";
import { processFile } from "./ocr";
import { storeCertificateHash, verifyCertificateHash, initializeBlockchain } from "./blockchain";
import { log } from "./vite";

// Create upload directories if they don't exist
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage_config = multer.diskStorage({
  destination: function (req: any, file: any, cb: any) {
    cb(null, uploadsDir);
  },
  filename: function (req: any, file: any, cb: any) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max file size
  },
  fileFilter: function (req: any, file: any, cb: any) {
    // Accept only PDFs and images
    if (
      file.mimetype === 'application/pdf' || 
      file.mimetype === 'image/jpeg' || 
      file.mimetype === 'image/png' || 
      file.mimetype === 'image/jpg'
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error('Only PDF, JPEG, and PNG files are allowed!'));
    }
  }
});

// Helper function to create enhanced verification response
function createVerificationResponse(certificate: any, blockchainVerified: boolean) {
  const metadata = certificate.metadata as Record<string, any>;
  
  return {
    verified: true,
    certificate: {
      id: certificate.id,
      hash: certificate.hash,
      holder_name: certificate.holder_name,
      certificate_type: certificate.certificate_type,
      issue_date: certificate.issue_date,
      transaction_hash: certificate.transaction_hash,
      issuer_id: certificate.issuer_id,
      issuer_name: metadata.issuer_name || '',
      qualifications: metadata.qualifications || [],
      additional_info: {
        expiry_date: metadata.expiry_date || null,
        verified_on_blockchain: blockchainVerified,
        verification_date: new Date().toISOString()
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize blockchain connection
  await initializeBlockchain();

  // API endpoint for uploading and processing certificates
  app.post('/api/certificates/upload', upload.single('certificate'), async (req: Request, res: Response) => {
    try {
      if (!(req as any).file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // Extract data from request body
      const { institution_name, institution_id, certificate_type } = req.body;

      if (!institution_name || !institution_id || !certificate_type) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      // Process the file - extract text and generate hash
      const filePath = (req as any).file.path;
      const result = await processFile(filePath, (req as any).file.mimetype);

      // Extract additional data from the result
      // With AI-powered extraction, we can get more detailed information
      const extracted = result.extractedData || {};
      
      // Use AI-extracted data if available, otherwise fall back to form input
      const holder_name = extracted.holderName || institution_name;
      const certificate_type_detected = extracted.certificateType || certificate_type;
      
      // Parse the date if available, otherwise use current date
      let issue_date = new Date();
      if (extracted.issueDate) {
        try {
          issue_date = new Date(extracted.issueDate);
          if (isNaN(issue_date.getTime())) {
            issue_date = new Date(); // Fallback if parsing fails
          }
        } catch (e) {
          // Keep default date
        }
      }

      // Use a private key from environment variables for blockchain interactions
      let privateKey = process.env.BLOCKCHAIN_PRIVATE_KEY || '';
      
      // For development, use a placeholder private key if none is provided
      if (!privateKey && process.env.NODE_ENV === 'development') {
        privateKey = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'; // Development test key
        log('Using development placeholder private key', 'blockchain');
      }
      
      if (!privateKey) {
        return res.status(500).json({ message: 'Blockchain configuration error' });
      }

      // Store the hash on the blockchain
      const transactionHash = await storeCertificateHash(result.hash, privateKey);

      // Create certificate entry in database with enhanced metadata
      const certificate = await storage.createCertificate({
        hash: result.hash,
        issuer_id: parseInt(institution_id),
        holder_name,
        certificate_type: certificate_type_detected, // Use the AI-detected certificate type
        issue_date,
        metadata: { 
          extracted_text: result.extractedText,
          institution_name,
          ai_extracted: result.extractedData || {},
          issuer_name: extracted.issuerName || institution_name,
          qualifications: extracted.qualifications || [],
          expiry_date: extracted.expiryDate || null
        },
        file_path: filePath,
        transaction_hash: transactionHash
      });

      // Return the certificate data with metadata
      res.status(200).json({
        message: 'Certificate processed successfully',
        certificate: {
          id: certificate.id,
          hash: certificate.hash,
          holder_name: certificate.holder_name,
          certificate_type: certificate.certificate_type,
          issue_date: certificate.issue_date,
          transaction_hash: certificate.transaction_hash,
          issuer_name: extracted.issuerName || institution_name,
          qualifications: extracted.qualifications || []
        }
      });
    } catch (error: any) {
      log(`Certificate upload error: ${error}`, 'api');
      res.status(500).json({ message: `Error processing certificate: ${error.message}` });
    }
  });

  // API endpoint for verifying certificates by uploading file
  app.post('/api/certificates/verify/file', upload.single('certificate'), async (req: Request, res: Response) => {
    try {
      if (!(req as any).file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // Process the file - extract text and generate hash
      const filePath = (req as any).file.path;
      const result = await processFile(filePath, (req as any).file.mimetype);

      // Check if the hash exists in our database
      const certificate = await storage.getCertificateByHash(result.hash);

      // Verify the hash on the blockchain
      const blockchainVerified = await verifyCertificateHash(result.hash);

      // Determine verification status
      const verified = certificate !== undefined && blockchainVerified;

      // Create verification record if we have a certificate
      if (certificate) {
        await storage.createVerification({
          certificate_id: certificate.id,
          verified_by: 1, // Simplified - would use logged-in user
          is_verified: verified
        });
      }

      if (verified && certificate) {
        // Return verification success with enhanced certificate details
        res.status(200).json(createVerificationResponse(certificate, blockchainVerified));
      } else {
        // Return verification failure
        res.status(200).json({
          verified: false,
          message: 'Certificate could not be verified'
        });
      }
    } catch (error: any) {
      log(`Certificate verification error: ${error}`, 'api');
      res.status(500).json({ message: `Error verifying certificate: ${error.message}` });
    }
  });

  // API endpoint for verifying certificates by hash
  app.post('/api/certificates/verify/hash', async (req: Request, res: Response) => {
    try {
      const { hash } = req.body;

      if (!hash) {
        return res.status(400).json({ message: 'Hash is required' });
      }

      // Check if the hash exists in our database
      const certificate = await storage.getCertificateByHash(hash);

      // Verify the hash on the blockchain
      const blockchainVerified = await verifyCertificateHash(hash);

      // Determine verification status
      const verified = certificate !== undefined && blockchainVerified;

      // Create verification record if we have a certificate
      if (certificate) {
        await storage.createVerification({
          certificate_id: certificate.id,
          verified_by: 1, // Simplified - would use logged-in user
          is_verified: verified
        });
      }

      if (verified && certificate) {
        // Return verification success with enhanced certificate details
        res.status(200).json(createVerificationResponse(certificate, blockchainVerified));
      } else {
        // Return verification failure
        res.status(200).json({
          verified: false,
          message: 'Certificate could not be verified'
        });
      }
    } catch (error: any) {
      log(`Certificate hash verification error: ${error}`, 'api');
      res.status(500).json({ message: `Error verifying certificate hash: ${error.message}` });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}