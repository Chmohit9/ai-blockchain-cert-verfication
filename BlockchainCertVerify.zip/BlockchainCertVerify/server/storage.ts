import { 
  users, 
  certificates, 
  verifications, 
  type User, 
  type InsertUser, 
  type Certificate, 
  type InsertCertificate,
  type Verification,
  type InsertVerification
} from "@shared/schema";
import { db } from './db';
import { eq } from 'drizzle-orm';

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Certificate operations
  createCertificate(certificate: InsertCertificate): Promise<Certificate>;
  getCertificate(id: number): Promise<Certificate | undefined>;
  getCertificateByHash(hash: string): Promise<Certificate | undefined>;
  
  // Verification operations
  createVerification(verification: InsertVerification): Promise<Verification>;
  getVerificationsForCertificate(certificateId: number): Promise<Verification[]>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Certificate operations
  async createCertificate(insertCertificate: InsertCertificate): Promise<Certificate> {
    const [certificate] = await db.insert(certificates).values(insertCertificate).returning();
    return certificate;
  }
  
  async getCertificate(id: number): Promise<Certificate | undefined> {
    const [certificate] = await db.select().from(certificates).where(eq(certificates.id, id));
    return certificate;
  }
  
  async getCertificateByHash(hash: string): Promise<Certificate | undefined> {
    const [certificate] = await db.select().from(certificates).where(eq(certificates.hash, hash));
    return certificate;
  }
  
  // Verification operations
  async createVerification(insertVerification: InsertVerification): Promise<Verification> {
    const [verification] = await db.insert(verifications).values(insertVerification).returning();
    return verification;
  }
  
  async getVerificationsForCertificate(certificateId: number): Promise<Verification[]> {
    return await db.select()
      .from(verifications)
      .where(eq(verifications.certificate_id, certificateId));
  }
}

// Create and export a singleton instance
export const storage = new DatabaseStorage();