import Tesseract from 'tesseract.js';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { log } from './vite';
import OpenAI from 'openai';

// Create temp directory for extracted text files if it doesn't exist
const tempDir = path.join(process.cwd(), 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Interface for extracted certificate data
interface ExtractedCertificateData {
  holderName?: string;
  issuerName?: string;
  certificateType?: string;
  issueDate?: string;
  expiryDate?: string;
  qualifications?: string[];
  additionalInfo?: Record<string, any>;
}

// Function to extract text from an image using Tesseract OCR
export async function extractTextFromImage(filePath: string): Promise<string> {
  try {
    const worker = await Tesseract.createWorker();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');
    
    log('Starting OCR processing on image', 'ocr');
    const { data: { text } } = await worker.recognize(filePath);
    
    await worker.terminate();
    log('OCR processing completed', 'ocr');
    
    return text;
  } catch (error) {
    log(`OCR processing error: ${error}`, 'ocr');
    throw new Error(`Failed to extract text from image: ${error}`);
  }
}

// Function to extract text from PDF
// Note: In a real implementation, you would use a PDF library like pdf.js or pdf-parse
// For this implementation, we'll assume PDF extraction is handled by converting to images first
export async function extractTextFromPDF(filePath: string): Promise<string> {
  // In a real implementation, you would:
  // 1. Convert PDF to images
  // 2. Extract text from each image
  // 3. Combine the results
  
  // For this implementation, we'll simulate PDF extraction
  try {
    log('Simulating PDF extraction (would use pdf-parse in production)', 'ocr');
    // Just use Tesseract directly on the PDF (this wouldn't work in reality)
    return await extractTextFromImage(filePath);
  } catch (error) {
    log(`PDF extraction error: ${error}`, 'ocr');
    throw new Error(`Failed to extract text from PDF: ${error}`);
  }
}

// Function to extract text based on file type
export async function extractTextFromFile(filePath: string, mimeType: string): Promise<string> {
  if (mimeType.startsWith('image/')) {
    return await extractTextFromImage(filePath);
  } else if (mimeType === 'application/pdf') {
    return await extractTextFromPDF(filePath);
  } else {
    throw new Error(`Unsupported file type: ${mimeType}`);
  }
}

// Function to analyze text using OpenAI to extract certificate data
async function analyzeTextWithAI(text: string): Promise<ExtractedCertificateData> {
  try {
    log('Starting AI analysis of extracted text', 'ocr');
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert in analyzing educational certificates and credentials. Extract structured information from the provided certificate text."
        },
        {
          role: "user",
          content: `Extract the following information from this certificate text in JSON format: 
          - holderName: The name of the person who received the certificate
          - issuerName: The institution that issued the certificate
          - certificateType: The type of certificate (degree, diploma, certification, etc.)
          - issueDate: The date when the certificate was issued (in YYYY-MM-DD format if possible)
          - expiryDate: The expiration date if applicable (in YYYY-MM-DD format if possible)
          - qualifications: An array of qualifications or achievements mentioned
          - additionalInfo: Any other relevant information

          Here is the certificate text:
          ${text}`
        }
      ],
      response_format: { type: "json_object" }
    });
    
    const resultContent = response.choices[0].message.content;
    log('AI analysis completed', 'ocr');
    
    if (!resultContent) {
      log('AI analysis returned empty content', 'ocr');
      return {};
    }
    
    try {
      return JSON.parse(resultContent) as ExtractedCertificateData;
    } catch (parseError) {
      log(`Error parsing AI response: ${parseError}`, 'ocr');
      return {};
    }
  } catch (error) {
    log(`AI analysis error: ${error}`, 'ocr');
    // Return empty object if AI analysis fails - we'll fall back to basic OCR
    return {};
  }
}

// Function to generate a hash from extracted text
export function generateHashFromText(text: string): string {
  return crypto.createHash('sha256').update(text).digest('hex');
}

// Function to handle the complete OCR and hash generation process
export async function processFile(filePath: string, mimeType: string): Promise<{
  extractedText: string;
  hash: string;
  extractedData?: ExtractedCertificateData;
}> {
  try {
    // Extract text from file
    const extractedText = await extractTextFromFile(filePath, mimeType);
    
    // Generate hash from extracted text
    const hash = generateHashFromText(extractedText);
    
    // Save extracted text to a temporary file for debugging
    const textFilePath = path.join(tempDir, `${path.basename(filePath)}.txt`);
    fs.writeFileSync(textFilePath, extractedText);
    
    // Use AI to extract structured data from the text
    let extractedData: ExtractedCertificateData | undefined;
    try {
      extractedData = await analyzeTextWithAI(extractedText);
      log('Successfully extracted structured data using AI', 'ocr');
      
      // Save extracted data to a JSON file for debugging
      const dataFilePath = path.join(tempDir, `${path.basename(filePath)}.json`);
      fs.writeFileSync(dataFilePath, JSON.stringify(extractedData, null, 2));
    } catch (aiError) {
      log(`AI extraction failed, continuing with basic OCR: ${aiError}`, 'ocr');
      // Fall back to basic OCR if AI fails
    }
    
    return {
      extractedText,
      hash,
      extractedData
    };
  } catch (error) {
    log(`File processing error: ${error}`, 'ocr');
    throw new Error(`Failed to process file: ${error}`);
  }
}
