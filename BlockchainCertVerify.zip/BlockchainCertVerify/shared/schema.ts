import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define the user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // admin, institute, recruiter, user
  wallet_address: text("wallet_address"),
  created_at: timestamp("created_at").defaultNow(),
});

// Define the certificate schema
export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  hash: text("hash").notNull().unique(),
  issuer_id: integer("issuer_id").references(() => users.id),
  holder_name: text("holder_name").notNull(),
  certificate_type: text("certificate_type").notNull(),
  issue_date: timestamp("issue_date").notNull(),
  metadata: jsonb("metadata"), // Additional certificate data
  file_path: text("file_path"), // Reference to the stored file
  transaction_hash: text("transaction_hash"), // Blockchain transaction hash
  created_at: timestamp("created_at").defaultNow(),
});

// Define schema for verification attempts
export const verifications = pgTable("verifications", {
  id: serial("id").primaryKey(),
  certificate_id: integer("certificate_id").references(() => certificates.id),
  verified_by: integer("verified_by").references(() => users.id),
  is_verified: boolean("is_verified").notNull(),
  verification_date: timestamp("verification_date").defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  wallet_address: true,
});

export const insertCertificateSchema = createInsertSchema(certificates).omit({
  id: true,
  created_at: true,
});

export const insertVerificationSchema = createInsertSchema(verifications).omit({
  id: true,
  verification_date: true,
});

// Create types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCertificate = z.infer<typeof insertCertificateSchema>;
export type Certificate = typeof certificates.$inferSelect;

export type InsertVerification = z.infer<typeof insertVerificationSchema>;
export type Verification = typeof verifications.$inferSelect;

// Certificate upload schema for validation
export const certificateUploadSchema = z.object({
  institution_name: z.string().min(1, "Institution name is required"),
  institution_id: z.string().min(1, "Institution ID is required"),
  certificate_type: z.string().min(1, "Certificate type is required"),
  // The file will be validated on the server
});

// Certificate verification schema for validation
export const certificateVerificationSchema = z.object({
  hash: z.string().optional(),
  // The file will be validated on the server
});
