import fs from 'fs';
import path from 'path';
import solc from 'solc';

// Path to the Solidity contract
const contractPath = path.resolve(__dirname, 'CertificateVerification.sol');
const contractSource = fs.readFileSync(contractPath, 'utf8');

// Compile the contract
function compileContract() {
  const input = {
    language: 'Solidity',
    sources: {
      'CertificateVerification.sol': {
        content: contractSource
      }
    },
    settings: {
      outputSelection: {
        '*': {
          '*': ['abi', 'evm.bytecode']
        }
      }
    }
  };

  console.log('Compiling contract...');
  const output = JSON.parse(solc.compile(JSON.stringify(input)));

  // Check for errors
  if (output.errors) {
    output.errors.forEach((error: any) => {
      console.error(error.formattedMessage);
    });
    
    if (output.errors.some((error: any) => error.severity === 'error')) {
      throw new Error('Contract compilation failed');
    }
  }

  // Get the contract
  const contract = output.contracts['CertificateVerification.sol']['CertificateVerification'];
  
  // Save the ABI and bytecode to files
  const buildDir = path.resolve(__dirname, 'build');
  
  if (!fs.existsSync(buildDir)) {
    fs.mkdirSync(buildDir, { recursive: true });
  }
  
  fs.writeFileSync(
    path.resolve(buildDir, 'CertificateVerification.abi.json'),
    JSON.stringify(contract.abi, null, 2)
  );
  
  fs.writeFileSync(
    path.resolve(buildDir, 'CertificateVerification.bin'),
    contract.evm.bytecode.object
  );
  
  console.log('Contract compiled successfully');
  
  return {
    abi: contract.abi,
    bytecode: contract.evm.bytecode.object
  };
}

// Export the compiler
export default compileContract;

// Run the compiler if called directly
if (require.main === module) {
  compileContract();
}
