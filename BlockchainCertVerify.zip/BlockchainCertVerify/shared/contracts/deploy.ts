import { ethers } from 'ethers';
import fs from 'fs';
import path from 'path';
import compileContract from './compile';

async function deployContract() {
  try {
    // Compile the contract
    const { abi, bytecode } = compileContract();
    
    // Get private key and provider URL from environment variables
    const privateKey = process.env.BLOCKCHAIN_PRIVATE_KEY;
    const providerUrl = process.env.POLYGON_MUMBAI_RPC_URL || 'https://rpc-mumbai.maticvigil.com';
    
    if (!privateKey) {
      throw new Error('Private key not found in environment variables');
    }
    
    console.log('Connecting to Polygon Mumbai Testnet...');
    
    // Create a wallet with the private key
    const provider = new ethers.JsonRpcProvider(providerUrl);
    const wallet = new ethers.Wallet(privateKey, provider);
    
    // Create a contract factory
    const factory = new ethers.ContractFactory(abi, bytecode, wallet);
    
    console.log('Deploying contract...');
    
    // Deploy the contract
    const contract = await factory.deploy();
    
    // Wait for the contract to be mined
    await contract.waitForDeployment();
    
    const contractAddress = await contract.getAddress();
    
    console.log('Contract deployed successfully!');
    console.log('Contract address:', contractAddress);
    
    // Save the contract address to a file
    const deploymentInfo = {
      address: contractAddress,
      network: 'polygon-mumbai',
      timestamp: new Date().toISOString()
    };
    
    const buildDir = path.resolve(__dirname, 'build');
    
    if (!fs.existsSync(buildDir)) {
      fs.mkdirSync(buildDir, { recursive: true });
    }
    
    fs.writeFileSync(
      path.resolve(buildDir, 'deployment.json'),
      JSON.stringify(deploymentInfo, null, 2)
    );
    
    return contractAddress;
  } catch (error) {
    console.error('Error deploying contract:', error);
    throw error;
  }
}

// Export the deployment function
export default deployContract;

// Run the deployment if called directly
if (require.main === module) {
  deployContract()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });
}
